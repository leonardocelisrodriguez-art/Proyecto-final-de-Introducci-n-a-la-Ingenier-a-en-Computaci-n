/*****************************************************************************************************************
	UNIVERSIDAD NACIONAL AUTONOMA DE MEXICO
	FACULTAD DE ESTUDIOS SUPERIORES -ARAGON-

	Computadoras y programacion. 
	(c) Celis Rodríguez Leonardo, 426124294
	
	Quiso decir: Programa principal de la aplicacion de la distancia de Levenstein.
	
******************************************************************************************************************/


#include "stdafx.h"
#include <string.h>
#include <stdio.h>
#include <iostream>
#include "corrector.h"

//Funciones publicas del proyecto
/*****************************************************************************************************************
	DICCIONARIO: Esta funcion crea el diccionario completo
	char *	szNombre				:	Nombre del archivo de donde se sacaran las palabras del diccionario	
	char	szPalabras[][TAMTOKEN]	:	Arreglo con las palabras completas del diccionario
	int		iEstadisticas[]			:	Arreglo con el numero de veces que aparecen las palabras en el diccionario
	int &	iNumElementos			:	Numero de elementos en el diccionario
******************************************************************************************************************/
void	Diccionario			(char *szNombre, char szPalabras[][TAMTOKEN], int iEstadisticas[], int &iNumElementos)
{
	char antman[][TAMTOKEN];
	int dummy[NUMPALABRAS] = { 0 };
	FILE* archivo;
	fopen_s(&archivo, szNombre, "r");
	if (archivo != NULL)
	{
		for (int i = 0; i < NUMPALABRAS; i++)
		{
			fscanf_s(archivo, "%s", antman[i], TAMTOKEN);
			int yesca = strlen(antman[i]);
			for (int x = 0; x < yesca; x++)
			{
				antman[i][x] = tolower(antman[i][x]);
			}
			for (int h = 0; h <= yesca; h++)
			{
				if (antman[i][h] == ';' || antman[i][h] == ',' || antman[i][h] == '(' || antman[i][h] == ')' || antman[i][h] == '.')
				{
					if (antman[i][h] < 'a' || antman[i][h] > 'z')
					{
						antman[i][h] = 0;
					}
				}
			}
			char aux;
			int bNoOrdenado = true;
			for (int pasada = 0; pasada < yesca - 1 && bNoOrdenado; pasada++)
			{
				bNoOrdenado = false;
				for (int z = 0; z < yesca - 1; z++)
				{
					if (antman[i][z] == 0)
					{
						aux = antman[i][z];
						antman[i][z] = antman[i][z + 1];
						antman[i][z + 1] = aux;
						bNoOrdenado = true;
					}
				}
			}
		}
	}
	for (int i = 0; i < NUMPALABRAS; i++)
	{
		dummy[i] = 1;
		for (int j = 0; j < NUMPALABRAS; j++)
		{
			if (i != j)
			{
				if (strcmp(antman[i], antman[j]) == 0)
				{
					antman[j][0] = '\0';
					dummy[i]++;
				}
			}
		}
	}
	char aux[1][TAMTOKEN];
	int auxE;
	for (int i = 0; i < NUMPALABRAS; i++)
	{
		for (int j = 0; j < (NUMPALABRAS - 1); j++)
		{
			if (strcmp(antman[j], antman[j + 1]) > 0)
			{
				strcpy_s(aux[0], antman[j]);
				strcpy_s(antman[j], antman[j + 1]);
				strcpy_s(antman[j + 1], aux[0]);

				auxE = dummy[j];
				dummy[j] = dummy[j + 1];
				dummy[j + 1] = auxE;
			}
		}
	}
	for (int d = 0; d < NUMPALABRAS; d++)
	{
		if (antman[d][0] != '\0')
		{
			iNumElementos = iNumElementos + 1;
		}
	}
	int g = 0;
	for (int u = 0; u < NUMPALABRAS; u++)
	{
		if (antman[u][0] != '\0')
		{
			strcpy_s(szPalabras[g], antman[u]);
			iEstadisticas[g] = dummy[u];
			g++;
		}
	}
}

/*****************************************************************************************************************
	ListaCandidatas: Esta funcion recupera desde el diccionario las palabras validas y su peso
	Regresa las palabras ordenadas por su peso
	char	szPalabrasSugeridas[][TAMTOKEN],	//Lista de palabras clonadas
	int		iNumSugeridas,						//Lista de palabras clonadas
	char	szPalabras[][TAMTOKEN],				//Lista de palabras del diccionario
	int		iEstadisticas[],					//Lista de las frecuencias de las palabras
	int		iNumElementos,						//Numero de elementos en el diccionario
	char	szListaFinal[][TAMTOKEN],			//Lista final de palabras a sugerir
	int		iPeso[],							//Peso de las palabras en la lista final
	int &	iNumLista)							//Numero de elementos en la szListaFinal
******************************************************************************************************************/
void	ListaCandidatas		(
	char	szPalabrasSugeridas[][TAMTOKEN],	//Lista de palabras clonadas
	int		iNumSugeridas,						//Lista de palabras clonadas
	char	szPalabras[][TAMTOKEN],				//Lista de palabras del diccionario
	int		iEstadisticas[],					//Lista de las frecuencias de las palabras
	int		iNumElementos,						//Numero de elementos en el diccionario
	char	szListaFinal[][TAMTOKEN],			//Lista final de palabras a sugerir
	int		iPeso[],							//Peso de las palabras en la lista final
	int &	iNumLista)							//Numero de elementos en la szListaFinal
{

	//Sustituya estas lineas por su c�digo
	strcpy(szListaFinal[0], szPalabrasSugeridas[ 0] ); //la palabra candidata
	iPeso[0] = iEstadisticas[0];			// el peso de la palabra candidata
	
	iNumLista = 1;							//Una sola palabra candidata
}

/*****************************************************************************************************************
	ClonaPalabras: toma una palabra y obtiene todas las combinaciones y permutaciones requeridas por el metodo
	char *	szPalabraLeida,						// Palabra a clonar
	char	szPalabrasSugeridas[][TAMTOKEN], 	//Lista de palabras clonadas
	int &	iNumSugeridas)						//Numero de elementos en la lista
******************************************************************************************************************/
void	ClonaPalabras(
	char *	szPalabraLeida,						// Palabra a clonar
	char	szPalabrasSugeridas[][TAMTOKEN], 	//Lista de palabras clonadas
	int &	iNumSugeridas)						//Numero de elementos en la lista
{
	//Sustituya estas lineas por su c�digo
	strcpy(szPalabrasSugeridas[0], szPalabraLeida); //lo que sea que se capture, es sugerencia
	iNumSugeridas = 1;							//Una sola palabra sugerida
}
